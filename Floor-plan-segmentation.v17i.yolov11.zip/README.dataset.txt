# Floor-plan-segmentation > 2024-09-12 10:22am
https://universe.roboflow.com/iiitbangalore/floor-plan-segmentation-dtr4r

Provided by a Roboflow user
License: MIT

Floor plan dataset for instance segmentation